package com.nets.cashout.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="cupd_txn")
public class CupdTxn implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private String f37;
	
	private String f38;
	
	@Column(name="f7_preauth")
	private String f7Preauth;
	
	@Column(name="f7_cancel")
	private String f7Cancel;
	
	@Column(name="f7_complete")
	private String f7Complete;
	
	@Column(name="f7_reversal")
	private String f7Reversal;

	private String message;
	
	@Column(name="reversal_message")
	private String reversalMessage;
	
	private int attempt;
	
	@Column(name="reversal_attempt")
	private int reversalAttempt;
	
	public String getF7Reversal() {
		return f7Reversal;
	}

	public void setF7Reversal(String f7Reversal) {
		this.f7Reversal = f7Reversal;
	}

	public String getReversalMessage() {
		return reversalMessage;
	}

	public void setReversalMessage(String reversalMessage) {
		this.reversalMessage = reversalMessage;
	}

	public int getAttempt() {
		return attempt;
	}

	public void setAttempt(int attempt) {
		this.attempt = attempt;
	}

	public int getReversalAttempt() {
		return reversalAttempt;
	}

	public void setReversalAttempt(int reversalAttempt) {
		this.reversalAttempt = reversalAttempt;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getF7Preauth() {
		return f7Preauth;
	}

	public void setF7Preauth(String f7Preauth) {
		this.f7Preauth = f7Preauth;
	}

	public String getF7Cancel() {
		return f7Cancel;
	}

	public void setF7Cancel(String f7Cancel) {
		this.f7Cancel = f7Cancel;
	}

	public String getF7Complete() {
		return f7Complete;
	}

	public void setF7Complete(String f7Complete) {
		this.f7Complete = f7Complete;
	}

	//bi-directional many-to-one association to H5Txn
	@ManyToOne
	@JoinColumn(name="h5_id")
	private H5Txn h5Txn;

	public CupdTxn() {
		
	}

	public String getF37() {
		return f37;
	}

	public void setF37(String f37) {
		this.f37 = f37;
	}

	public String getF38() {
		return f38;
	}

	public void setF38(String f38) {
		this.f38 = f38;
	}
	
	public H5Txn getH5Txn() {
		return h5Txn;
	}

	public void setH5Txn(H5Txn h5Txn) {
		this.h5Txn = h5Txn;
	}
}
