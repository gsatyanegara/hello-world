package com.nets.cashout.cupd;

import javax.annotation.PostConstruct;

import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.channel.NACChannel;
import org.jpos.iso.packager.GenericPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Channel8583 {
	
	private static Logger logger = LoggerFactory.getLogger(Channel8583.class);
	
	@Value("${packager}")
	String packager8583;
	@Value("${ip}")
	String ip;
	@Value("${port}")
	int port;
	
	private static NACChannel channel = null;
	private static ISOPackager packager = null;
	private static Channel8583 channel8583 = null;
	private static String pIp;
	private static int pPort;
	
	@PostConstruct
	public void constructChannel8583() {
		try {
			packager = new GenericPackager (packager8583);
			channel = new NACChannel(ip, port, packager, new byte[4]);
			channel.setTimeout(60000);
			if (!channel.isConnected())
					channel.connect();
			logger.info("Connected to " + ip + ":" + port);
			channel.setTimeout(30000);
			channel.getSocket().setSoLinger(false, 0);
			pIp = ip;
			pPort = port;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	public static Channel8583 getInstance() {
		
		if (channel8583 == null) {
			channel8583 = new Channel8583();
		}
		
		return channel8583;
	}
	
	public static NACChannel getChannel() {
		return channel;
	}

	public static void reconnect() {
		logger.info("Channel reconnnect start");
		try {
			channel.disconnect();
		} catch (Exception e) {
			logger.error("Error during disconnect.");
		}
		channel = null;
		
		try {
			channel = new NACChannel(pIp, pPort, packager, new byte[4]);
			channel.setTimeout(60000);
			if (!channel.isConnected())
					channel.connect();
			logger.info("Connected to " + pIp + ":" + pPort);
			channel.setTimeout(30000);
			channel.getSocket().setSoLinger(false, 0);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void send(ISOMsg data) {
		try {
			channel.send(data);
		} catch (Exception e) {
			reconnect();
			try {
				logger.info("Resend after reconnect " + ISOUtil.byte2hex(data.getBytes()));
				channel.send(data);
			} catch (Exception ex) {
				logger.error(ex.getMessage());
			}
		}
	}
	
	public static void send(byte[] data) {
		try {
			channel.send(data);
		} catch (Exception e) {
			reconnect();
			try {
				logger.info("Resend after reconnect " + ISOUtil.byte2hex(data));
				channel.send(data);
			} catch (Exception ex) {
				logger.error(ex.getMessage());
			}
		}
	}
	
}