package com.nets.cashout.cupd;

import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.integration.aop.AbstractMessageSourceAdvice;
import org.springframework.integration.core.MessageSource;
import org.springframework.messaging.Message;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

@Component
public class PollerTriggerAdvice extends AbstractMessageSourceAdvice {
	private Logger logger = LoggerFactory.getLogger(PollerTriggerAdvice.class);

	@Autowired
	@Qualifier("cashoutTaskExecutor")
	TaskExecutor taskExecutor;
	
	ThreadPoolTaskExecutor taskPool = null;
	ThreadPoolExecutor pool = null;

	@PostConstruct
	public void initThreadPoolObject() {
		taskPool = (ThreadPoolTaskExecutor) taskExecutor;
		pool = taskPool.getThreadPoolExecutor();
	}
	
	@Override
	public Message<?> afterReceive(Message<?> msg, MessageSource<?> msgSource) {
		if(msg != null) {
			if(msg.getPayload() instanceof List) {
				List<?> recordList = (List<?>) msg.getPayload();
				logger.info("Poller receive {} items!", recordList.size());
			}
		}
		
		return msg;
	}

	@Override
	public boolean beforeReceive(MessageSource<?> arg0) {
		int queueSize = pool.getQueue().size();
		int activePool = pool.getActiveCount();
		
		logger.debug("Check before polling - Thread Pool Queue Size : {} - Active Pool : {}", queueSize, activePool);
		
		if((queueSize + activePool) > 0) {
			return false;
		}
		
		return true;
	}	
}