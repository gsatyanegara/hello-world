package com.nets.cashout.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the audit database table.
 * 
 */
@Entity
@Table(name="audit")
@NamedQuery(name="Audit.findAll", query="SELECT a FROM Audit a")
public class Audit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name="end_status")
	private String endStatus;

	@Column(name="init_status")
	private String initStatus;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="last_update")
	private Date lastUpdate;

	//bi-directional many-to-one association to H5Txn
	@ManyToOne
	@JoinColumn(name="txn_id")
	private H5Txn h5Txn;

	public Audit() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEndStatus() {
		return this.endStatus;
	}

	public void setEndStatus(String endStatus) {
		this.endStatus = endStatus;
	}

	public String getInitStatus() {
		return this.initStatus;
	}

	public void setInitStatus(String initStatus) {
		this.initStatus = initStatus;
	}

	public Date getLastUpdate() {
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public H5Txn getH5Txn() {
		return this.h5Txn;
	}

	public void setH5Txn(H5Txn h5Txn) {
		this.h5Txn = h5Txn;
	}

}