package com.nets.cashout.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the h5_txn database table.
 * 
 */
@Entity
@Table(name="h5_txn")
@NamedQuery(name="H5Txn.findAll", query="SELECT h FROM H5Txn h")
public class H5Txn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name="account_name")
	private String accountName;

	@Column(name="account_no")
	private String accountNo;
	
	@Column(name="card_num")
	private String cardNum;

	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	private double amount;

	private String bank;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="dbs_pending_check")
	private Date dbsPendingCheck;

	private String email;

	@Column(name="error_code")
	private String errorCode;

	@Column(name="error_description")
	private String errorDescription;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="last_update")
	private Date lastUpdate;

	private String phone;

//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name="request_time")
//	private Date requestTime;

	private String state;

	private String uid;

	//bi-directional many-to-one association to Audit
	@OneToMany(mappedBy="h5Txn")
	private List<Audit> audits;

	//bi-directional many-to-one association to DbsTxn
	@OneToMany(mappedBy="h5Txn")
	private List<DbsTxn> dbsTxns;

	public H5Txn() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountName() {
		return this.accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public double getAmount() {
		return this.amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getBank() {
		return this.bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public Date getDbsPendingCheck() {
		return this.dbsPendingCheck;
	}

	public void setDbsPendingCheck(Date dbsPendingCheck) {
		this.dbsPendingCheck = dbsPendingCheck;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getErrorCode() {
		return this.errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return this.errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public Date getLastUpdate() {
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

//	public Date getRequestTime() {
//		return this.requestTime;
//	}
//
//	public void setRequestTime(Date requestTime) {
//		this.requestTime = requestTime;
//	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUid() {
		return this.uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public List<Audit> getAudits() {
		return this.audits;
	}

	public void setAudits(List<Audit> audits) {
		this.audits = audits;
	}

	public Audit addAudit(Audit audit) {
		getAudits().add(audit);
		audit.setH5Txn(this);

		return audit;
	}

	public Audit removeAudit(Audit audit) {
		getAudits().remove(audit);
		audit.setH5Txn(null);

		return audit;
	}

	public List<DbsTxn> getDbsTxns() {
		return this.dbsTxns;
	}

	public void setDbsTxns(List<DbsTxn> dbsTxns) {
		this.dbsTxns = dbsTxns;
	}

	public DbsTxn addDbsTxn(DbsTxn dbsTxn) {
		getDbsTxns().add(dbsTxn);
		dbsTxn.setH5Txn(this);

		return dbsTxn;
	}

	public DbsTxn removeDbsTxn(DbsTxn dbsTxn) {
		getDbsTxns().remove(dbsTxn);
		dbsTxn.setH5Txn(null);

		return dbsTxn;
	}

}