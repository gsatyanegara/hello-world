package com.nets.cashout.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.nets.cashout.cupd.Channel8583;

@Configuration
public class SchedulerConfig {

	private Logger logger = LoggerFactory.getLogger(SchedulerConfig.class);
	@Autowired
	Channel8583 ch8583;
	
	@Value("${heartbeat}")
	String heartbeat;
	
	@Scheduled(cron="${heartbeat.cron}")
	public void sendHeartbeat() {
		ch8583.send(heartbeat.getBytes());
		logger.info("Sent 0000 to CUPD host");
	}
}
