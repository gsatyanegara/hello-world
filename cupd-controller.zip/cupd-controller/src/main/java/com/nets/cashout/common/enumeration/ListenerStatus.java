package com.nets.cashout.common.enumeration;

import static com.nets.cashout.CashoutConstant.LSTN_STATUS_ERROR;
import static com.nets.cashout.CashoutConstant.LSTN_STATUS_RUNNING;
import static com.nets.cashout.CashoutConstant.LSTN_STATUS_STOP;

public enum ListenerStatus {
	RUNNING (LSTN_STATUS_RUNNING), 
	STOP (LSTN_STATUS_STOP),
	ERROR (LSTN_STATUS_ERROR);
	
	private String statusString;
	
	ListenerStatus(String statusString) {
		this.statusString = statusString;
	}

	public String statusString() {
		return statusString;
	}
}
