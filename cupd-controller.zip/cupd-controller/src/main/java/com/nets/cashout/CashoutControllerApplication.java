package com.nets.cashout;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nets.cashout.listener.ShutdownListener;

@SpringBootApplication(scanBasePackages = {"com.nets"})
public class CashoutControllerApplication {

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(CashoutControllerApplication.class);
		app.setBannerMode(Banner.Mode.OFF);

		//app.setWebApplicationType(WebApplicationType.NONE);
		
		app.addListeners(new ShutdownListener());
		
		app.run(args);		
	}
}

