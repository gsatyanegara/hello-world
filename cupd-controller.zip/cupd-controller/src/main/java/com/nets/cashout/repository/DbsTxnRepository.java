package com.nets.cashout.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.nets.cashout.model.DbsTxn;

@Transactional(readOnly = true)
public interface DbsTxnRepository extends JpaRepository<DbsTxn, Integer> {
	public DbsTxn findById(int id);
	
//	@Modifying
//	@Transactional
//	@Query(nativeQuery = true, value = "delete from csiinwardfile where batchStatusId = ?1")
//	public int deleteByIdBatchStatusId(Integer batchStatusId);
//	public Csibatchstatus findById(int id);
//	public List<Csibatchstatus> findByProcessingIdAndProcessingStatus(String processingId, Character processingStatus);
//	
//	public List<Csibatchstatus> findByClearingDateAndBankAndBranchAndTransactionTypeAndMailBoxAndProcessingIdAndProcessingStatus(String clearingDate, String bank, String branch, String transactionType, Character mailBox, String processingId, Character processingStatus);
//	default public List<Csibatchstatus> findICCRecoveryBatchStatus(String clearingDate, String bank, String branch, String transactionType, Character mailBox, String processingId, Character processingStatus) {
//		return findByClearingDateAndBankAndBranchAndTransactionTypeAndMailBoxAndProcessingIdAndProcessingStatus(clearingDate, bank, branch, transactionType, mailBox, processingId, processingStatus);
//	}
//	
//	public Csibatchstatus findTop1ByClearingDateAndBankAndBranchAndTransactionTypeAndBatchNoAndProcessingIdOrderByIdDesc(String clearingDate, String bank, String branch, String transactionType, String batchNo, String processingId);
//	default public Csibatchstatus findOCCRecoveryBatchStatus(String clearingDate, String bank, String branch, String transactionType, String batchNo, String processingId) {
//		return findTop1ByClearingDateAndBankAndBranchAndTransactionTypeAndBatchNoAndProcessingIdOrderByIdDesc(clearingDate, bank, branch, transactionType, batchNo, processingId);
//	}
//	
//	public List<Csibatchstatus> findByClearingDateLessThan(String clearingDate);
//	
//	@Query(value = "select distinct c.ProcessingID from csibatchstatus c", nativeQuery = true)
//	public List<String> findHostname();
//	
//	@Modifying
//	@Transactional
//	public long deleteByClearingDateLessThan(String clearingDate);
}