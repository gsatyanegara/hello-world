package com.nets.cashout.cupd;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.persistence.EntityManagerFactory;

import org.slf4j.LoggerFactory;
import org.aopalliance.aop.Advice;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.jpa.core.JpaExecutor;
import org.springframework.integration.jpa.inbound.JpaPollingChannelAdapter;
import org.springframework.integration.scheduling.PollerMetadata;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.nets.cashout.common.enumeration.ListenerStatus;
import com.nets.cashout.model.H5Txn;

import static com.nets.cashout.CashoutConstant.TIME_SECONDS_FORMAT;

@Service
public class CUPDListener implements SmartLifecycle {
	private Logger logger = LoggerFactory.getLogger(CUPDListener.class);

	@Autowired
	@Qualifier("cashoutTaskExecutor")
	TaskExecutor taskExecutor;

	@Autowired
	@Qualifier("cupdControlBus")
	DirectChannel controlBusChannel;

	@Autowired
	@Qualifier("cupdBusOutput")
	QueueChannel busOutputChannel;

	@Autowired
	EntityManagerFactory entityManagerFactory;

	@Autowired
	PollerTriggerAdvice pollerTrigger;

	@Value("${cashout.cupd.listener.query}")
	String query;
	
	@Value("${cashout.cupd.listener.poller.delay}")
	long pollerInterval;

	@Value("${cashout.cupd.shutdown.timeout}")
	long shutdownTimeout;

	@Value("${cashout.cupd.shutdown.check.interval}")
	int timeoutCheckInterval;

	public class CUPDListenerTrigger implements Trigger {

		@Override
		public Date nextExecutionTime(TriggerContext triggerContext) {
			if (triggerContext.lastCompletionTime() == null) { 
				return new Date(System.currentTimeMillis() + pollerInterval);
			} else { 
				return new Date(triggerContext.lastCompletionTime().getTime() + pollerInterval);
			}
		}
	}

	@Bean(name = "cupdPoller")
	public PollerMetadata cupdPoller() {
		PollerMetadata pollerMetadata = new PollerMetadata();
		ArrayList<Advice> adviceChain = new ArrayList<Advice>();
		adviceChain.add(pollerTrigger);
		CUPDListenerTrigger trigger = new CUPDListenerTrigger();
		pollerMetadata.setMaxMessagesPerPoll(1);
		pollerMetadata.setTrigger(trigger);
		pollerMetadata.setAdviceChain(adviceChain);
		return pollerMetadata;
	}

	@Bean("cupdInboundChannelAdapter")
	@InboundChannelAdapter(
			value = "cupdDatabaseListenerChannel", poller = @Poller("cupdPoller")
			)
	public MessageSource<?> cupdListener() {
		return new JpaPollingChannelAdapter(jpaExecutor());
	}

	@Bean
	public JpaExecutor jpaExecutor() {
		JpaExecutor executor = new JpaExecutor(this.entityManagerFactory);
		executor.setJpaQuery(query);
		
		executor.setEntityClass(H5Txn.class);
		return executor;
	}

	@Override
	public void start() {
		logger.info("Start CUPD Listener triggered!");
		logger.info("CUPD Listener Status : " + startInboundChannelAdapter().toString());
	}
	@Override
	public void stop() {
		logger.info("Stop CUPD Listener triggered!");
		logger.info("CUPD Listener Status : " + stopInboundChannelAdapter().toString());
	}
	@Override
	public int getPhase() {
		return Integer.MAX_VALUE - 1;
	}
	@Override
	public boolean isAutoStartup() {
		return true;
	}
	@Override
	public boolean isRunning() {
		return (isInboundChannelAdapterRunning() == ListenerStatus.RUNNING ? true : false);
	}
	@Override
	public void stop(Runnable callback) {
		logger.info("Stop CUPD Listener started!");

		ThreadPoolTaskExecutor cupdTaskPool = (ThreadPoolTaskExecutor) taskExecutor;
		ThreadPoolExecutor cupdPool = cupdTaskPool.getThreadPoolExecutor();

		logger.info("Stopping CUPD listener..");
		this.stopInboundChannelAdapter();

		logger.info("Shutting down CUPD thread pool..");
		cupdTaskPool.shutdown();

		logger.info("Total item still in queue : " + cupdPool.getQueue().size());

		if(cupdPool.getQueue().size() > 0) {
			logger.info("Emptying queue..");
			cupdPool.getQueue().clear();
			cupdPool.purge();
		}

		logger.info("Current active process : " + cupdPool.getActiveCount());

		long startTimer = System.nanoTime();
		long elapsedTime = 0;
		shutdownTimeout = (shutdownTimeout > 0) ? shutdownTimeout : Integer.MAX_VALUE;

		logger.info("Shutdown timeout : " + TIME_SECONDS_FORMAT.format(shutdownTimeout / 1000) + " second(s)");

		while((cupdPool.getActiveCount() > 0) && (elapsedTime < shutdownTimeout)) {			
			try {
				logger.info("Waiting.. " + TIME_SECONDS_FORMAT.format(elapsedTime / 1000) + " seconds - Active Thread : " + cupdPool.getActiveCount()); 
				logger.debug("Core Thread : {} - Max Thread : {} - Queue Size : {}", cupdPool.getCorePoolSize(), cupdPool.getMaximumPoolSize(), cupdPool.getQueue().size());
				Thread.sleep(timeoutCheckInterval);				
			} catch (InterruptedException e) {
				logger.error("Interrupted while waiting for CUPD process to complete!", e);
			}

			elapsedTime = TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTimer, TimeUnit.NANOSECONDS);
		}

		callback.run();
	}

	public ListenerStatus startInboundChannelAdapter() {
		ListenerStatus status = ListenerStatus.ERROR;
		status = this.isInboundChannelAdapterRunning();

		logger.info("Database  listener status : " + status.toString());

		if(status == ListenerStatus.STOP) {
			logger.info("Triggering start to file listener..");
			controlBusChannel.send(new GenericMessage<String>("@'CUPDListener.cupdListener.inboundChannelAdapter'.start()"));

			status = this.isInboundChannelAdapterRunning(); 

			if(status == ListenerStatus.RUNNING) {
				logger.info("CUPD listener start successfully!");				
			} else {
				logger.error("CUPD listener failed to start!");
			}	
		} else if(status == ListenerStatus.RUNNING){
			logger.warn("CUPD listener is already running!");
		}

		return status;
	}

	public ListenerStatus stopInboundChannelAdapter() {
		ListenerStatus status = ListenerStatus.ERROR;
		status = this.isInboundChannelAdapterRunning();

		logger.info("CUPD listener status : " + status.toString());

		if(status == ListenerStatus.RUNNING) {
			logger.info("Triggering stop to  CUPD listener..");
			controlBusChannel.send(new GenericMessage<String>("@'CUPDListener.cupdListener.inboundChannelAdapter'.stop()"));

			status = this.isInboundChannelAdapterRunning(); 

			if(status == ListenerStatus.RUNNING) {
				logger.error("CUPD listener still running!");				
			} else {
				logger.info("CUPD listener stopped successfully!");
			}	
		} else if(status == ListenerStatus.STOP){
			logger.warn("CUPD listener is not running!");
		}

		return status;
	}

	public ListenerStatus isInboundChannelAdapterRunning() {
		controlBusChannel.send(new GenericMessage<String>("@'CUPDListener.cupdListener.inboundChannelAdapter'.isRunning()"));
		Object o = ((Message<?>) busOutputChannel.receive()).getPayload();

		busOutputChannel.clear();

		if(o instanceof Boolean) {
			return ((Boolean) o ? ListenerStatus.RUNNING : ListenerStatus.STOP);
		} else {
			logger.error("Unkown message received when getting channel adapter status for  CUPD Listener! Object : " + o.getClass());
			return ListenerStatus.ERROR;
		}
	}
}
