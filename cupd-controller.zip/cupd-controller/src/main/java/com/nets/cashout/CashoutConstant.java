package com.nets.cashout;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

public final class CashoutConstant {
	public final static String SEMICOLON = ";"; 
	
	public final static String THREAD_NAME = "worker";
	
	public final static String LSTN_STATUS_RUNNING = "RUNNING";
	public final static String LSTN_STATUS_STOP = "STOP";
	public final static String LSTN_STATUS_ERROR = "ERROR";
	
	public static final NumberFormat TIME_SECONDS_FORMAT = new DecimalFormat("#0.00");
}