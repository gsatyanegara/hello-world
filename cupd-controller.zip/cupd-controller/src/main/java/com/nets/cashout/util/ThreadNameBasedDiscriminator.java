//package com.bcsis.csi.util;
//
//import static com.bcsis.csi.common.util.CSIConstant.ICC_THREAD_NAME;
//import static com.bcsis.csi.common.util.CSIConstant.LOG_FILE_APPLICATION;
//import static com.bcsis.csi.common.util.CSIConstant.LOG_FILE_ICC;
//import static com.bcsis.csi.common.util.CSIConstant.LOG_FILE_OCC;
//import static com.bcsis.csi.common.util.CSIConstant.OCC_THREAD_NAME;
//
//import ch.qos.logback.classic.spi.ILoggingEvent;
//import ch.qos.logback.core.sift.Discriminator;
//
//public class ThreadNameBasedDiscriminator implements Discriminator<ILoggingEvent> {
// 
//    private static final String KEY = "threadName";
// 
//    private boolean started;
// 
//    @Override
//    public String getDiscriminatingValue(ILoggingEvent iLoggingEvent) {
//        String threadname = Thread.currentThread().getName();
//        if(threadname.contains(OCC_THREAD_NAME)) {
//        	return LOG_FILE_OCC;
//        } else if(threadname.contains(ICC_THREAD_NAME)) {
//        	return LOG_FILE_ICC;
//        } else {
//        	return LOG_FILE_APPLICATION;
//        }
//    }
// 
//    @Override
//    public String getKey() {
//        return KEY;
//    }
// 
//    public void start() {
//        started = true;
//    }
// 
//    public void stop() {
//        started = false;
//    }
// 
//    public boolean isStarted() {
//        return started;
//    }
//}