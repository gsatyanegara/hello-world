package com.nets.cashout.exception.handler;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomRejectedExecutionHandler implements RejectedExecutionHandler {
	private Logger logger = LoggerFactory.getLogger(CustomRejectedExecutionHandler.class);
	
	@Override
	public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
		logger.error("Task discarded! Active pool : {} - Core pool : {} - Max pool : {} - Queue size : {}",
				executor.getActiveCount(), executor.getCorePoolSize(), executor.getMaximumPoolSize(), executor.getQueue().size());
	}
	
}