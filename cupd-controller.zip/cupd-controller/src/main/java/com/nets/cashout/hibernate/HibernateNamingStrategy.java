package com.nets.cashout.hibernate;

import java.io.Serializable;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;

/**
 *  Default implementation will add underscores to table and column name
 */
public class HibernateNamingStrategy extends PhysicalNamingStrategyStandardImpl implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public static final HibernateNamingStrategy INSTANCE = new HibernateNamingStrategy();

	@Override
	public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment context) {
		return new Identifier(name.getText(), name.isQuoted());
	}

	@Override
	public Identifier toPhysicalColumnName(Identifier name, JdbcEnvironment context) {
		return new Identifier(name.getText(), name.isQuoted());
	}
}