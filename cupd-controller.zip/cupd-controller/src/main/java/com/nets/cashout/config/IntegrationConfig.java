package com.nets.cashout.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.MessageChannels;

import com.nets.cashout.cupd.handler.CUPDHandler;


@Configuration
public class IntegrationConfig {
	
	@Autowired
	CUPDHandler cupdHandler;
	
	@Autowired
	@Qualifier("cashoutTaskExecutor")
	TaskExecutor taskExecutor;
	
	@Bean
	public IntegrationFlow cupdFlow() {
		return IntegrationFlows
					.from("cupdDatabaseListenerChannel")
					.split()
					.channel(MessageChannels.executor(taskExecutor))
					.handle(cupdHandler, "processTxn")
					.get();
	}	
	
	/**
	 * 	Control bus	
	 */
	@Bean("cupdControlBus")
	public DirectChannel getCUPDControlBusChannel() {
		return new DirectChannel();
	}

	@Bean("cupdBusOutput")
	public QueueChannel getCUPDBusOutputChannel() {
		return new QueueChannel();
	}

	@Bean 
	public IntegrationFlow cupdControlBusFlow() {
		return IntegrationFlows.from(getCUPDControlBusChannel())
				.controlBus()
				.channel(getCUPDBusOutputChannel())
				.get();
	}
}