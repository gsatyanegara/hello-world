package com.nets.cashout.logger;

import java.util.Arrays;
import java.util.List;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.filter.AbstractMatcherFilter;
import ch.qos.logback.core.spi.FilterReply;

public class LoggerNonExceptionFilter extends AbstractMatcherFilter<LoggingEvent> {

    @Override	
    public FilterReply decide(LoggingEvent loggingEvent) {
    	if (!isStarted()) {
            return FilterReply.NEUTRAL;
        }

        List<Level> eventsToKeep = Arrays.asList(Level.DEBUG, Level.INFO, Level.TRACE);
        if (eventsToKeep.contains(loggingEvent.getLevel())) {
            return FilterReply.NEUTRAL;
        }
        else {
            return FilterReply.DENY;
        }
    }

}