package com.nets.cashout;

import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.format.DateTimeFormatter;

import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.packager.GenericPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.nets.cashout.cupd.Channel8583;
import com.nets.cashout.cupd.handler.CUPDHandler;



@Component
public class ListenControllerRunner implements ApplicationRunner {
	private static final Logger logger = LoggerFactory.getLogger(ListenControllerRunner.class);
	
	@Value("${port}")
	int port;
	@Value("${packager}")
	String packager;
	@Value("${field.mti.preauth.response}")
	String preauthResponseMti;
	@Value("${field.mti.cancel.response}")
	String cancelResponseMti;
	@Value("${field.mti.complete.response}")
	String completeResponseMti;
	@Value("${field.mti.reversal.response}")
	String reversalResponseMti;
	@Value("${field.3.preauth}")
	String preauthProcCode;
	@Value("${field.3.cancel}")
	String cancelProcCode;
	@Value("${field.3.complete}")
	String completeProcCode;
	
	@Autowired
	Channel8583 ch8583;
	
	@Autowired
	CUPDHandler cupdHandler;
	
	@Override
	public void run(ApplicationArguments args) {
		logger.info("Starting NETSPAY Listen Controller..");
		
		while (true) {
			try (ServerSocket listener = new ServerSocket(port)) {
				try (Socket socket = listener.accept()) {
					InputStream is = socket.getInputStream();
					byte[] buffer = new byte[4];
					int read;
					while ((read = is.read(buffer)) != -1) {
						String output = new String(buffer, 0, read);
						//String output = ISOUtil.hexString(buffer);
						logger.info("received byte len: " + ISOUtil.hexString(buffer));
						logger.info("len: " + Integer.parseInt(output));
						if (Integer.parseInt(output) > 0) {
							byte[] contentBuffer = new byte[Integer.parseInt(output)];
							read = is.read(contentBuffer);
							String content = new String(contentBuffer, 0, read);
							logger.info("byte content: " + ISOUtil.hexString(contentBuffer));
							logger.info("content: " + content);
							
							byte[] isoByte = new byte[contentBuffer.length - 46];
							System.arraycopy(contentBuffer, 46, isoByte, 0, contentBuffer.length-46);
							ISOMsg incoming = new ISOMsg();
							incoming.setPackager(new GenericPackager(packager));
							incoming.unpack(isoByte);
							logger.info("Bytes successfully parsed to ISO8583");
							
							if (incoming.getMTI().equalsIgnoreCase(preauthResponseMti) && incoming.getString(3).equalsIgnoreCase(preauthProcCode)) {
								cupdHandler.handlePreauthorizationResponse(incoming);
							} else if (incoming.getMTI().equalsIgnoreCase(cancelResponseMti) && incoming.getString(3).equalsIgnoreCase(cancelProcCode)) {
								cupdHandler.handleCancellationResponse(incoming);
							} else if (incoming.getMTI().equalsIgnoreCase(completeResponseMti) && incoming.getString(3).equalsIgnoreCase(completeProcCode)) {
								cupdHandler.handleCompletionResponse(incoming);
							} else if (incoming.getMTI().equalsIgnoreCase(reversalResponseMti)) {
								cupdHandler.handleReversalResponse(incoming);
							}
						}
						
					}
				} catch (Exception ex) {
					logger.error(ex.getMessage());
				}
			
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
	}
}
