package com.nets.cashout.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.nets.cashout.model.CupdTxn;
import com.nets.cashout.model.H5Txn;


@Transactional(readOnly = true)
public interface CupdTxnRepository extends JpaRepository<CupdTxn, String> {
	public CupdTxn findByF37(String f37);
	public CupdTxn findByH5Txn (H5Txn h5Txn);
	
	//@Query("SELECT t FROM cupd_txn t where t.f37 = ?1 AND t.f38 = ?2")
	public CupdTxn findByF37AndF38(String f37, String f38);
	
}