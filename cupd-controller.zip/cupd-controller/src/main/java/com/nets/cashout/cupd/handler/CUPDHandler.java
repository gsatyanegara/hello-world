package com.nets.cashout.cupd.handler;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.packager.GenericPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.nets.cashout.cupd.Channel8583;
import com.nets.cashout.model.CupdTxn;
import com.nets.cashout.model.H5Txn;
import com.nets.cashout.repository.CupdTxnRepository;
import com.nets.cashout.repository.H5TxnRepository;

import static com.nets.cashout.CashoutConstant.TIME_SECONDS_FORMAT;

@Service
public class CUPDHandler {
	private static final Logger logger = LoggerFactory.getLogger(CUPDHandler.class);
	
	@Autowired
	Channel8583 ch8583;
	@Autowired
	H5TxnRepository h5Repository;
	@Autowired
	CupdTxnRepository cupdRepository;
	
	//header related
	@Value("${header.length}")
	String length;
	@Value("${header.flagVersion}")
	String flagVersion;
	@Value("${header.destinationId}")
	String destinationId;
	@Value("${header.sourceId}")
	String sourceId;
	@Value("${header.reserved}")
	String reserved;
	@Value("${header.batchNo}")
	String batchNo;
	@Value("${header.txnInfo}")
	String txnInfo;
	@Value("${header.userInfo}")
	String userInfo;
	@Value("${header.rejectCode}")
	String rejectCode;
	
	//ISO and field related
	@Value("${packager}")
	String packager8583;
	@Value("${field.mti.preauth}")
	String preauthMti;
	@Value("${field.mti.cancel}")
	String cancelMti;
	@Value("${field.mti.complete}")
	String completeMti;
	@Value("${field.mti.reversal}")
	String reversalMti;
	@Value("${field.2.append}")
	String panAppend;
	@Value("${field.3.preauth}")
	String preauthProcCode;
	@Value("${field.3.cancel}")
	String cancelProcCode;
	@Value("${field.3.complete}")
	String completeProcCode;
	@Value("${field.18}")
	String merchantType;
	@Value("${field.19}")
	String merchantCountryCode;
	@Value("${field.22}")
	String posEntryModeCode;
	@Value("${field.25}")
	String posConditionCode;
	@Value("${field.32}")
	String acquiringId;
	@Value("${field.33}")
	String forwardingId;
	@Value("${field.41}")
	String acceptorTerminalId;
	@Value("${field.42}")
	String acceptorId;
	@Value("${field.43}")
	String acceptorNameLoc;	
	@Value("${field.49}")
	String currencyCode;
	@Value("${field.60}")
	String reservedField;
	@Value("${field.100}")
	String receivingId;
	
	// DB signal related
	// preauth
	@Value("${cashout.preauth.signal}")
	String preauthSignal;
	@Value("${cashout.preauth.inprogress.signal}")
	String preauthInprogressSignal;
	@Value("${cashout.preauth.success.signal}")
	String preauthSuccessSignal;
	@Value("${cashout.preauth.fail.signal}")
	String preauthFailSignal;
	@Value("${cashout.preauth.timeout.error.code}")
	String preauthTimeoutErrorCode;
	// cancel
	@Value("${cashout.cancel.signal}")
	String cancelSignal;
	@Value("${cashout.cancel.inprogress.signal}")
	String cancelInprogressSignal;
	@Value("${cashout.cancel.success.signal}")
	String cancelSuccessSignal;
	@Value("${cashout.cancel.fail.signal}")
	String cancelFailSignal;
	@Value("${cashout.cancel.timeout.error.code}")
	String cancelTimeoutErrorCode;
	// complete
	@Value("${cashout.complete.signal}")
	String completeSignal;
	@Value("${cashout.complete.inprogress.signal}")
	String completeInprogressSignal;
	@Value("${cashout.complete.success.signal}")
	String completeSuccessSignal;
	@Value("${cashout.complete.fail.signal}")
	String completeFailSignal;
	@Value("${cashout.complete.timeout.error.code}")
	String completeTimeoutErrorCode;
	// reversal
	@Value("${cashout.reversal.preauth.inprogress.signal}")
	String reversalPreauthInprogressSignal;
	@Value("${cashout.reversal.cancel.inprogress.signal}")
	String reversalCancelInprogressSignal;
	@Value("${cashout.reversal.complete.inprogress.signal}")
	String reversalCompleteInprogressSignal;
	@Value("${cashout.reversal.fail.signal}")
	String reversalFailSignal;
	@Value("${cashout.reversal.fail.signal.complete}")
	String reversalFailSignalComplete;
	@Value("${cashout.reversal.fail.signal.cancellation}")
	String reversalFailSignalCancellation;
	@Value("${cashout.reversal.fail.signal.preauthinprocess}")
	String reversalFailSignalPreauthInprocess;
	@Value("${cashout.reversal.timeout.error.code}")
	String reversalTimeoutErrorCode;
	
	@Value("${cashout.cupd.txn.retry}")
	int txnRetry;
	@Value("${cashout.cupd.txn.attempt}")
	int txnMaxAttempt;
	@Value("${cashout.cupd.reversal.retry}")
	int reversalRetry;
	@Value("${cashout.cupd.reversal.attempt}")
	int reversalMaxAttempt;
	
	public void processTxn (Message<H5Txn> msg) {
		H5Txn payload = msg.getPayload();
		
		String state = payload.getState();
		SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
		
		try {
			if (state.equalsIgnoreCase(preauthSignal))
				sendPreauthorizationMessage(payload);
			else if (state.equalsIgnoreCase(cancelSignal))
				sendPreauthorizationCancellationMessage(payload);
			else if (state.equalsIgnoreCase(completeSignal))
				sendPreauthorizationCompletionMessage(payload);
			else if (state.equalsIgnoreCase(preauthInprogressSignal)) {
				CupdTxn cupdTxn = cupdRepository.findByH5Txn(payload);
				String initAttempt = cupdTxn.getF7Preauth();
				String now = DateTimeFormatter.ofPattern("MMddHHmmss").format(LocalDateTime.now());
				long difference = sdf.parse(now).getTime() - sdf.parse(initAttempt).getTime();
				if (difference > txnRetry && cupdTxn.getAttempt() < txnMaxAttempt) {
					logger.info("Attempt " + cupdTxn.getAttempt() + " to send reversal preauthorization for f37: " + cupdTxn.getF37());
					sendReversalMessage(payload);
				} else if (cupdTxn.getAttempt() == txnMaxAttempt) {
					logger.info("Max Attempt detected for preauthorization f37: " + cupdTxn.getF37());
					payload.setState(preauthFailSignal);
					payload.setErrorCode(preauthTimeoutErrorCode);
					h5Repository.save(payload);
				}
				
			}
			else if (state.equalsIgnoreCase(cancelInprogressSignal)) {
				CupdTxn cupdTxn = cupdRepository.findByH5Txn(payload);
				String initAttempt = cupdTxn.getF7Cancel();
				String now = DateTimeFormatter.ofPattern("MMddHHmmss").format(LocalDateTime.now());
				long difference = sdf.parse(now).getTime() - sdf.parse(initAttempt).getTime();
				if (difference > txnRetry && cupdTxn.getAttempt() < txnMaxAttempt) {
					logger.info("Attempt " + cupdTxn.getAttempt() + " to send reversal cancellation for f37: " + cupdTxn.getF37() + " and f38: " + cupdTxn.getF38());
					sendReversalMessage(payload);
				} else if (cupdTxn.getAttempt() == txnMaxAttempt) {
					logger.info("Max Attempt detected for cancellation f37: " + cupdTxn.getF37() + " and f38: " + cupdTxn.getF38());
					payload.setState(cancelFailSignal);
					payload.setErrorCode(cancelTimeoutErrorCode);
					h5Repository.save(payload);
				}
			}
			else if (state.equalsIgnoreCase(completeInprogressSignal)) {
				CupdTxn cupdTxn = cupdRepository.findByH5Txn(payload);
				String initAttempt = cupdTxn.getF7Complete();
				String now = DateTimeFormatter.ofPattern("MMddHHmmss").format(LocalDateTime.now());
				long difference = sdf.parse(now).getTime() - sdf.parse(initAttempt).getTime();
				if (difference > txnRetry && cupdTxn.getAttempt() < txnMaxAttempt) {
					logger.info("Attempt " + cupdTxn.getAttempt() + " to send reversal completion for f37: " + cupdTxn.getF37() + " and f38: " + cupdTxn.getF38());
					sendReversalMessage(payload);
				} else if (cupdTxn.getAttempt() == txnMaxAttempt) {
					logger.info("Max Attempt detected for completion f37: " + cupdTxn.getF37() + " and f38: " + cupdTxn.getF38());
					payload.setState(completeFailSignal);
					payload.setErrorCode(completeTimeoutErrorCode);
					h5Repository.save(payload);
				}
			}
			else if (state.equalsIgnoreCase(reversalPreauthInprogressSignal) || state.equalsIgnoreCase(reversalCancelInprogressSignal) || state.equalsIgnoreCase(reversalCompleteInprogressSignal)) {
				CupdTxn cupdTxn = cupdRepository.findByH5Txn(payload);
				String initAttempt = cupdTxn.getF7Reversal();
				String now = DateTimeFormatter.ofPattern("MMddHHmmss").format(LocalDateTime.now());
				long difference = sdf.parse(now).getTime() - sdf.parse(initAttempt).getTime();
				
				if (difference > reversalRetry && cupdTxn.getReversalAttempt() < reversalMaxAttempt) {
					logger.info("Attempt " + (cupdTxn.getReversalAttempt()+1) + " to send repeat reversal for f37: " + cupdTxn.getF37() + " and f38: " + cupdTxn.getF38());
					sendRepeatMessage(cupdTxn, 0);
				} else if (cupdTxn.getReversalAttempt() == reversalMaxAttempt){
					logger.info("Max Attempt detected for reversal f37: " + cupdTxn.getF37() + " and f38: " + cupdTxn.getF38());
					
					String failSignal = reversalFailSignal;
					if (state.equalsIgnoreCase(reversalPreauthInprogressSignal)) {
						logger.info("Setting failsignal for - " + reversalPreauthInprogressSignal);
						failSignal = reversalFailSignalPreauthInprocess;
					} else if (state.equalsIgnoreCase(reversalCancelInprogressSignal)) {
						logger.info("Setting failsignal for - " + reversalCancelInprogressSignal);
						failSignal = reversalFailSignalCancellation;
					} else if (state.equalsIgnoreCase(reversalCompleteInprogressSignal)) {
						logger.info("Setting failsignal for - " + reversalCompleteInprogressSignal);
						failSignal = reversalFailSignalComplete;
					}
					payload.setState(failSignal);
					payload.setErrorCode(reversalTimeoutErrorCode);
					h5Repository.save(payload);
				}
			}
			
			
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
	}
	
	public void sendPreauthorizationMessage(H5Txn payload) {
		logger.info("Sending preauthorization message for " + payload.getCardNum() + " amount " + payload.getAmount());
		ISOMsg iso = new ISOMsg();
		try {
			ISOPackager packager = new GenericPackager(packager8583);
			iso.setPackager(packager);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMddHHmmss");
			DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("HHmmss");
			DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("MMdd");
			DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("YYMMddHHmmss");
			LocalDateTime now = LocalDateTime.now();
			String cleanAmount = TIME_SECONDS_FORMAT.format(payload.getAmount()).replace(".", "");
			
			iso.setMTI(preauthMti);
			iso.set(2, panAppend + payload.getCardNum()); // PAN
			iso.set(3, preauthProcCode); // Processing code
			iso.set(4, cleanAmount); // transaction amount
			iso.set(7, dtf.format(now)); // transmission date time
			iso.set(11, dtf2.format(now)); // system trace audit number
			iso.set(12, dtf2.format(now)); // local transaction time
			iso.set(13, dtf3.format(now)); // expiry date
			iso.set(18, merchantType); // merchant type
			iso.set(19, merchantCountryCode); // merchant country code
			iso.set(22, posEntryModeCode); // point of service entry mode code
			iso.set(25, posConditionCode); // point of service condition code
			iso.set(32, acquiringId); // acquiring institution id num 
			iso.set(33, forwardingId); // forwarding institution id num
			iso.set(37, dtf4.format(now)); // retrieval ref number;
			iso.set(41, acceptorTerminalId); // card acceptor terminal id
			iso.set(42, acceptorId); // card acceptor id
			iso.set(43, acceptorNameLoc); // card acceptor name location
			iso.set(49, currencyCode); // currency code
			iso.set(60, reservedField); // reserved field
			iso.set(100, receivingId); // receiving id
			
			byte[] isoByte = iso.pack();
			iso.setHeader(generateHeader(isoByte.length));
			logger.info("Preauthorization message: " + ISOUtil.hexString(isoByte));
			logger.info("Preauthorization f37: " + dtf4.format(now));
			ch8583.send(iso);
			logger.info("Preauthorization sent");
			CupdTxn cupdTxn = new CupdTxn();
			cupdTxn.setH5Txn(payload);
			cupdTxn.setF37(dtf4.format(now));
			cupdTxn.setF7Preauth(dtf.format(now));
			cupdTxn.setMessage(ISOUtil.hexString(isoByte));
			cupdTxn.setAttempt(1);
			cupdRepository.save(cupdTxn);
			payload.setState(preauthInprogressSignal);
			payload.setLastUpdate(new Date());
			h5Repository.save(payload);
			logger.info("Preauthorization persisted to DB and updated state to " + preauthInprogressSignal);
			
			
		} catch (Exception e) {
			logger.error(e.toString());
		}
	}
	
	public void sendPreauthorizationCancellationMessage(H5Txn payload) {
		logger.info("Sending cancellation message for " + payload.getCardNum() + " amount " + payload.getAmount());
		ISOMsg iso = new ISOMsg();
		try {
			ISOPackager packager = new GenericPackager(packager8583);
			iso.setPackager(packager);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMddHHmmss");
			DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("HHmmss");
			DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("MMdd");
			LocalDateTime now = LocalDateTime.now();
			String cleanAmount = TIME_SECONDS_FORMAT.format(payload.getAmount()).replace(".", "");
			
			iso.setMTI(cancelMti);
			iso.set(2, panAppend + payload.getCardNum()); // PAN
			iso.set(3, cancelProcCode); // Processing code
			iso.set(4, cleanAmount); // transaction amount
			iso.set(7, dtf.format(now)); // transmission date time
			iso.set(11, dtf2.format(now)); // system trace audit number
			iso.set(12, dtf2.format(now)); // local transaction time
			iso.set(13, dtf3.format(now)); // expiry date
			iso.set(18, merchantType); // merchant type
			iso.set(19, merchantCountryCode); // merchant country code
			iso.set(22, posEntryModeCode); // point of service entry mode code  
			iso.set(25, posConditionCode); // point of service condition code
			iso.set(32, acquiringId); // acquiring institution id num 
			iso.set(33, forwardingId); // forwarding institution id num
			CupdTxn cupdTxn = cupdRepository.findByH5Txn(payload);
			iso.set(37, cupdTxn.getF37()); // retrieval ref number;
			iso.set(38, cupdTxn.getF38());
			iso.set(41, acceptorTerminalId); // card acceptor terminal id
			iso.set(42, acceptorId); // card acceptor id
			iso.set(43, acceptorNameLoc); // card acceptor name location
			iso.set(49, currencyCode); // currency code
			iso.set(60, reservedField); // reserved field
			iso.set(100, receivingId); // receiving id
			
			byte[] isoByte = iso.pack();
			iso.setHeader(generateHeader(isoByte.length));
			logger.info("Cancellation message: " + ISOUtil.hexString(isoByte));
			logger.info("Cancellation f37: " + cupdTxn.getF37() + " with f38: " + cupdTxn.getF38());
			ch8583.send(iso);
			logger.info("Cancellation sent!");
			payload.setState(cancelInprogressSignal);
			payload.setLastUpdate(new Date());
			h5Repository.save(payload);
			cupdTxn.setF7Cancel(dtf.format(now));
			cupdTxn.setMessage(ISOUtil.hexString(isoByte));
			cupdTxn.setAttempt(1);
			cupdRepository.save(cupdTxn);
			logger.info("Updated f7 cancellation and state to " + cancelInprogressSignal);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	public void sendPreauthorizationCompletionMessage(H5Txn payload) {
		logger.info("Sending completion message for " + payload.getCardNum() + " amount " + payload.getAmount());
		ISOMsg iso = new ISOMsg();
		try {
			ISOPackager packager = new GenericPackager(packager8583);
			iso.setPackager(packager);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMddHHmmss");
			DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("HHmmss");
			DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("MMdd");
			LocalDateTime now = LocalDateTime.now();
			String cleanAmount = TIME_SECONDS_FORMAT.format(payload.getAmount()).replace(".", "");
			
			iso.setMTI(completeMti);
			iso.set(2, panAppend + payload.getCardNum()); // PAN
			iso.set(3, completeProcCode); // Processing code
			iso.set(4, cleanAmount); // transaction amount
			iso.set(7, dtf.format(now)); // transmission date time
			iso.set(11, dtf2.format(now)); // system trace audit number
			iso.set(12, dtf2.format(now)); // local transaction time
			iso.set(13, dtf3.format(now)); // expiry date
			iso.set(18, merchantType); // merchant type
			iso.set(19, merchantCountryCode); // merchant country code
			iso.set(22, posEntryModeCode); // point of service entry mode code  
			iso.set(25, posConditionCode); // point of service condition code
			iso.set(32, acquiringId); // acquiring institution id num 
			iso.set(33, forwardingId); // forwarding institution id num
			CupdTxn cupdTxn = cupdRepository.findByH5Txn(payload);
			iso.set(37, cupdTxn.getF37()); // retrieval ref number;
			iso.set(38, cupdTxn.getF38());
			iso.set(41, acceptorTerminalId); // card acceptor terminal id
			iso.set(42, acceptorId); // card acceptor id
			iso.set(43, acceptorNameLoc); // card acceptor name location
			iso.set(49, currencyCode); // currency code
			iso.set(60, reservedField); // reserved field
			iso.set(100, receivingId); // receiving id
			
			byte[] isoByte = iso.pack();
			iso.setHeader(generateHeader(isoByte.length));
			logger.info("Completion message: " + ISOUtil.hexString(isoByte));
			logger.info("Completion f37: " + cupdTxn.getF37() + " with f38: " + cupdTxn.getF38());
			ch8583.send(iso);
			logger.info("Completion sent!");
			payload.setState(completeInprogressSignal);
			payload.setLastUpdate(new Date());
			h5Repository.save(payload);
			cupdTxn.setF7Complete(dtf.format(now));
			cupdTxn.setMessage(ISOUtil.hexString(isoByte));
			cupdTxn.setAttempt(1);
			cupdRepository.save(cupdTxn);
			logger.info("Updated f7 complete and state to " + completeInprogressSignal);
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	public void sendReversalMessage(H5Txn payload) {
		logger.info("Sending reversal message for " + payload.getCardNum() + " amount " + payload.getAmount());
		ISOMsg iso = new ISOMsg();
		try {
			ISOPackager packager = new GenericPackager(packager8583);
			iso.setPackager(packager);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMddHHmmss");
			DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("HHmmss");
			DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("MMdd");
			LocalDateTime now = LocalDateTime.now();
			String cleanAmount = TIME_SECONDS_FORMAT.format(payload.getAmount()).replace(".", "");
			String nextState = "ERR";
			
			iso.setMTI(reversalMti);
			iso.set(2, panAppend + payload.getCardNum()); // PAN
			if (payload.getState().equalsIgnoreCase(preauthInprogressSignal)) {
				iso.set(3, preauthProcCode); // Processing code
				nextState = reversalPreauthInprogressSignal;
			} else if (payload.getState().equalsIgnoreCase(cancelInprogressSignal)) {
				iso.set(3, cancelProcCode); // Processing code
				nextState = reversalCancelInprogressSignal;
			} else if (payload.getState().equalsIgnoreCase(completeInprogressSignal)) {
				iso.set(3, completeProcCode); // Processing code
				nextState = reversalCompleteInprogressSignal;
			}
			iso.set(4, cleanAmount); // transaction amount
			iso.set(7, dtf.format(now)); // transmission date time
			iso.set(11, dtf2.format(now)); // system trace audit number
			iso.set(12, dtf2.format(now)); // local transaction time
			iso.set(13, dtf3.format(now)); // expiry date
			iso.set(18, merchantType); // merchant type
			iso.set(19, merchantCountryCode); // merchant country code
			iso.set(22, posEntryModeCode); // point of service entry mode code  
			iso.set(25, posConditionCode); // point of service condition code
			iso.set(32, acquiringId); // acquiring institution id num 
			iso.set(33, forwardingId); // forwarding institution id num
			CupdTxn cupdTxn = cupdRepository.findByH5Txn(payload);
			iso.set(37, cupdTxn.getF37()); // retrieval ref number;
			iso.set(38, cupdTxn.getF38());
			iso.set(41, acceptorTerminalId); // card acceptor terminal id
			iso.set(42, acceptorId); // card acceptor id
			iso.set(43, acceptorNameLoc); // card acceptor name location
			iso.set(49, currencyCode); // currency code
			iso.set(60, reservedField); // reserved field
			iso.set(100, receivingId); // receiving id
			
			//field 90
			ISOMsg tempIso = new ISOMsg();
			tempIso.setPackager(packager);
			tempIso.unpack(hexStringToByteArray(cupdTxn.getMessage()));
			String f90 = tempIso.getMTI() + tempIso.getValue(11) + tempIso.getValue(7) + "000" + tempIso.getValue(32) + "000" + tempIso.getValue(33);
			logger.info("Setting field 90 to: " + f90);
			iso.set(90, f90);
			//field 90
			
			byte[] isoByte = iso.pack();
			iso.setHeader(generateHeader(isoByte.length));
			logger.info("Reversal message: " + ISOUtil.hexString(isoByte));
			logger.info("Reversal f37: " + cupdTxn.getF37() + " with f38: " + cupdTxn.getF38());
			ch8583.send(iso);
			logger.info("Reversal sent!");
			payload.setState(nextState);
			payload.setLastUpdate(new Date());
			h5Repository.save(payload);
			cupdTxn.setF7Reversal(dtf.format(now));
			cupdTxn.setReversalMessage(ISOUtil.hexString(isoByte));
			cupdTxn.setReversalAttempt(1);
			cupdRepository.save(cupdTxn);
			logger.info("Updated f7 complete and state to " + nextState);
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	public void handlePreauthorizationResponse(ISOMsg response) {
		CupdTxn cupdTxn = cupdRepository.findByF37(response.getString(37));
		if (response.getString(39).equalsIgnoreCase("00")) {
			cupdTxn.setF38(response.getString(38));
			cupdRepository.save(cupdTxn);
			logger.info("Success preauthorization received");
			logger.info("Updated f38 " + response.getString(38) + " for f37 " + response.getString(37));
			
			H5Txn h5Txn = cupdTxn.getH5Txn();
			h5Txn.setState(preauthSuccessSignal);
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + preauthSuccessSignal);
		} else {
			cupdTxn.setF38(response.getString(38));
			cupdRepository.save(cupdTxn);
			logger.info("Failed preauthorization received with error code " + response.getString(39));
			logger.info("Updated f38 " + response.getString(38) + " for f37 " + response.getString(37));
			
			H5Txn h5Txn = cupdTxn.getH5Txn();
			h5Txn.setState(preauthFailSignal);
			h5Txn.setErrorCode(response.getString(39));
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + preauthFailSignal);
		}
	}
	
	public void handleCancellationResponse(ISOMsg response) {
		CupdTxn cupdTxn = cupdRepository.findByF37(response.getString(37));
		if (response.getString(39).equalsIgnoreCase("00")) {
			logger.info("Success cancellation received");
			H5Txn h5Txn = cupdTxn.getH5Txn();
			h5Txn.setState(cancelSuccessSignal);
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + cancelSuccessSignal);
		} else {
			logger.info("Failed cancellation received with error code " + response.getString(39));
			H5Txn h5Txn = cupdTxn.getH5Txn();
			h5Txn.setState(cancelFailSignal);
			h5Txn.setErrorCode(response.getString(39));
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + cancelFailSignal);
		}
	}
	
	public void handleCompletionResponse(ISOMsg response) {
		CupdTxn cupdTxn = cupdRepository.findByF37AndF38(response.getString(37), response.getString(38));
		if (response.getString(39).equalsIgnoreCase("00")) {
			logger.info("Success completion received");
			H5Txn h5Txn = cupdTxn.getH5Txn();
			h5Txn.setState(completeSuccessSignal);
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + completeSuccessSignal);
		} else {
			logger.info("Failed completion received with error code " + response.getString(39));
			if (cupdTxn == null)
				cupdTxn = cupdRepository.findByF37(response.getString(37));
			H5Txn h5Txn = cupdTxn.getH5Txn();
			h5Txn.setState(completeFailSignal);
			h5Txn.setErrorCode(response.getString(39));
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + completeFailSignal);
		}
	}
	
	public void handleReversalResponse(ISOMsg response) {
		CupdTxn cupdTxn = cupdRepository.findByF37(response.getString(37));
		if (response.getString(39).equalsIgnoreCase("00")) {
			logger.info("Success reversal received");
			H5Txn h5Txn = cupdTxn.getH5Txn();
			String nextState = "ERR";
			if (h5Txn.getState().equalsIgnoreCase(reversalPreauthInprogressSignal)) {
				logger.info("Send repeat preauth for f37: " + cupdTxn.getF37());
				nextState = preauthInprogressSignal;
				sendRepeatMessage(cupdTxn, 1);
			} else if (h5Txn.getState().equalsIgnoreCase(reversalCancelInprogressSignal)) {
				logger.info("Send repeat cancel for f37: " + cupdTxn.getF37());
				nextState = cancelInprogressSignal;
				sendRepeatMessage(cupdTxn, 4);
			} else if (h5Txn.getState().equalsIgnoreCase(reversalCompleteInprogressSignal)) {
				logger.info("Send repeat complete for f37: " + cupdTxn.getF37());
				nextState = completeInprogressSignal;
				sendRepeatMessage(cupdTxn, 3);
			}
			h5Txn.setState(nextState);
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + nextState);
		} else {
			logger.info("Failed reversal received with error code " + response.getString(39));
			H5Txn h5Txn = cupdTxn.getH5Txn();
			String failSignal = reversalFailSignal;
			if (h5Txn.getState().equalsIgnoreCase(reversalPreauthInprogressSignal)) {
				logger.info("Setting failsignal for - " + reversalPreauthInprogressSignal);
				failSignal = reversalFailSignalPreauthInprocess;
			} else if (h5Txn.getState().equalsIgnoreCase(reversalCancelInprogressSignal)) {
				logger.info("Setting failsignal for - " + reversalCancelInprogressSignal);
				failSignal = reversalFailSignalCancellation;
			} else if (h5Txn.getState().equalsIgnoreCase(reversalCompleteInprogressSignal)) {
				logger.info("Setting failsignal for - " + reversalCompleteInprogressSignal);
				failSignal = reversalFailSignalComplete;
			}
			h5Txn.setState(failSignal);
			h5Txn.setErrorCode(response.getString(39));
			h5Txn.setLastUpdate(new Date());
			h5Repository.save(h5Txn);
			logger.info("Updated state id " + h5Txn.getId() + " to " + reversalFailSignal);
		}
	}
	
	// Type 0 for reversal
	// Type 1 for preauth
	// Type 3 for completion
	// Type 4 for cancellation
	public void sendRepeatMessage(CupdTxn payload, int type) {
		try {
			ISOMsg iso = new ISOMsg();
			ISOPackager packager = new GenericPackager(packager8583);
			byte[] isoByte = hexStringToByteArray(payload.getMessage());
			iso.setPackager(packager);
			iso.unpack(isoByte);
			iso.setHeader(generateHeader(isoByte.length));
			//
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMddHHmmss");
			DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("HHmmss");
			LocalDateTime now = LocalDateTime.now();
			if (type != 0) {
				iso.set(7, dtf.format(now));
				iso.set(11, dtf2.format(now));
			}
			//
			ch8583.send(iso);
			
			
			if (type == 1) {
				logger.info("Sent repeat preauthorization for f37: " + payload.getF37());
				payload.setF7Preauth(dtf.format(now));
				payload.setMessage(ISOUtil.hexString(iso.pack()));
			} else if (type == 3) {
				logger.info("Sent repeat completion for f37: " + payload.getF37() + " and f38: " + payload.getF38());
				payload.setF7Complete(dtf.format(now));
				payload.setMessage(ISOUtil.hexString(iso.pack()));
			} else if (type == 4) {
				logger.info("Sent repeat cancellation for f37: " + payload.getF37() + " and f38: " + payload.getF38());
				payload.setF7Cancel(dtf.format(now));
				payload.setMessage(ISOUtil.hexString(iso.pack()));
			} else if (type == 0) {
				logger.info("Sent repeat reversal for f37: " + payload.getF37() + " and f38: " + payload.getF38());
				payload.setF7Reversal(dtf.format(now));
				payload.setReversalMessage(ISOUtil.hexString(iso.pack()));
			}
			
			if (type == 0) 
				payload.setReversalAttempt(payload.getReversalAttempt() + 1);
			else
				payload.setAttempt(payload.getAttempt() + 1);
			cupdRepository.save(payload);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
	}
	
	public byte[] generateHeader (int msgLen) {
		
		// Header Length
		byte[] h1 = ISOUtil.int2byte(Integer.parseInt(length));
		
		// Flag Version
		int fvDecimal = Integer.parseInt(flagVersion,2);
		String fvHexStr = Integer.toString(fvDecimal,16);
		byte[] h2 = ISOUtil.int2byte(fvDecimal);
		
		// Total length
		int totalMsgLen = msgLen + Integer.parseInt(length);
		String totalByteStr = String.format("%4s", Integer.toString(totalMsgLen)).replace(' ', '0');
		byte[] h3 = totalByteStr.getBytes();
		
		// Destination id
		byte[] h4 = destinationId.getBytes();
		
		// Source id
		byte[] h5 = sourceId.getBytes();
		
		// Reserved
		byte[] h6 = new byte[3];
		ISOUtil.str2hex(reserved, false, h6, 0);
		
		// Batch no
		byte[] h7 = new byte[1];
		ISOUtil.str2hex(batchNo, false, h7, 0);
		
		// Txn info
		byte[] h8 = new byte[8];
		ISOUtil.str2hex(txnInfo, false, h8, 0);
		
		// User info
		byte[] h9 = new byte[1];
		ISOUtil.str2hex(userInfo, false, h9, 0);
		
		// Reject code
		byte[] h10 = rejectCode.getBytes();
		
		// Header bytes
		byte[] combine1 = appendByte(h1, h2);
		byte[] combine2 = appendByte(combine1, h3);
		byte[] combine3 = appendByte(combine2, h4);
		byte[] combine4 = appendByte(combine3, h5);
		byte[] combine5 = appendByte(combine4, h6);
		byte[] combine6 = appendByte(combine5, h7);
		byte[] combine7 = appendByte(combine6, h8);
		byte[] combine8 = appendByte(combine7, h9);
		byte[] combine9 = appendByte(combine8, h10);

		// add the additional header
		byte[] combine10 = appendByte(combine2, combine9);
		
		return combine10;
	}
	
	public static byte[] appendByte (byte[] append1, byte[] append2) {
		
		byte[] appendFinal = new byte[append1.length + append2.length];
		System.arraycopy(append1, 0, appendFinal, 0, append1.length);
		System.arraycopy(append2, 0, appendFinal, append1.length, append2.length);
		return appendFinal;
	}
	
	public static byte[] hexStringToByteArray(String s) {
	    int len = s.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
	                             + Character.digit(s.charAt(i+1), 16));
	    }
	    return data;
	}
	

}
