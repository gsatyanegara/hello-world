package com.nets.cashout.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the dbs_txn database table.
 * 
 */
@Entity
@Table(name="dbs_txn")
@NamedQuery(name="DbsTxn.findAll", query="SELECT d FROM DbsTxn d")
public class DbsTxn implements Serializable {
	private static final long serialVersionUID = 1L;

//	private int id;
	
	@Id
	private String msgId;

	private String advEmails;

	private String advMode;

	private String advPhones;

	private String customerReference;

	private String orgId;

	private String purposeOfPayment;

	private String receiverAccountNo;

	private String receiverAddress;

	private String receiverBankCountryCode;

	private String receiverName;

	private String receiverProxyType;

	private String receiverProxyValue;

	private String receiverSwiftBic;

	@Temporal(TemporalType.TIMESTAMP)
	private Date requestTimeStamp;

	@Temporal(TemporalType.TIMESTAMP)
	private Date responseTimeStamp;

	private String rmtInfoClientRef;

	private String rmtInfoInvoiceDetails;

	private String rmtInfoPaymentDetails;

	private String senderAccountNo;

	private String senderBankCountryCode;

	private String senderMandateId;

	private String senderName;

	private String senderSwiftBic;

	private double txnAmount;

	private String txnCcy;

	private String txnDate;

	private String txnRefId;

	private String txnRejectCode;

	private double txnSettlementAmt;

	@Temporal(TemporalType.TIMESTAMP)
	private Date txnSettlementDate;

	private String txnStatus;

	private String txnStatusDescription;

	private String txnType;

	//bi-directional many-to-one association to H5Txn
	@ManyToOne
	@JoinColumn(name="id")
	private H5Txn h5Txn;

	public DbsTxn() {
	}

//	public int getId() {
//		return this.id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
	
	public String getMsgId() {
		return this.msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public String getAdvEmails() {
		return this.advEmails;
	}

	public void setAdvEmails(String advEmails) {
		this.advEmails = advEmails;
	}

	public String getAdvMode() {
		return this.advMode;
	}

	public void setAdvMode(String advMode) {
		this.advMode = advMode;
	}

	public String getAdvPhones() {
		return this.advPhones;
	}

	public void setAdvPhones(String advPhones) {
		this.advPhones = advPhones;
	}

	public String getCustomerReference() {
		return this.customerReference;
	}

	public void setCustomerReference(String customerReference) {
		this.customerReference = customerReference;
	}

	public String getOrgId() {
		return this.orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getPurposeOfPayment() {
		return this.purposeOfPayment;
	}

	public void setPurposeOfPayment(String purposeOfPayment) {
		this.purposeOfPayment = purposeOfPayment;
	}

	public String getReceiverAccountNo() {
		return this.receiverAccountNo;
	}

	public void setReceiverAccountNo(String receiverAccountNo) {
		this.receiverAccountNo = receiverAccountNo;
	}

	public String getReceiverAddress() {
		return this.receiverAddress;
	}

	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}

	public String getReceiverBankCountryCode() {
		return this.receiverBankCountryCode;
	}

	public void setReceiverBankCountryCode(String receiverBankCountryCode) {
		this.receiverBankCountryCode = receiverBankCountryCode;
	}

	public String getReceiverName() {
		return this.receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverProxyType() {
		return this.receiverProxyType;
	}

	public void setReceiverProxyType(String receiverProxyType) {
		this.receiverProxyType = receiverProxyType;
	}

	public String getReceiverProxyValue() {
		return this.receiverProxyValue;
	}

	public void setReceiverProxyValue(String receiverProxyValue) {
		this.receiverProxyValue = receiverProxyValue;
	}

	public String getReceiverSwiftBic() {
		return this.receiverSwiftBic;
	}

	public void setReceiverSwiftBic(String receiverSwiftBic) {
		this.receiverSwiftBic = receiverSwiftBic;
	}

	public Date getRequestTimeStamp() {
		return this.requestTimeStamp;
	}

	public void setRequestTimeStamp(Date requestTimeStamp) {
		this.requestTimeStamp = requestTimeStamp;
	}

	public Date getResponseTimeStamp() {
		return this.responseTimeStamp;
	}

	public void setResponseTimeStamp(Date responseTimeStamp) {
		this.responseTimeStamp = responseTimeStamp;
	}

	public String getRmtInfoClientRef() {
		return this.rmtInfoClientRef;
	}

	public void setRmtInfoClientRef(String rmtInfoClientRef) {
		this.rmtInfoClientRef = rmtInfoClientRef;
	}

	public String getRmtInfoInvoiceDetails() {
		return this.rmtInfoInvoiceDetails;
	}

	public void setRmtInfoInvoiceDetails(String rmtInfoInvoiceDetails) {
		this.rmtInfoInvoiceDetails = rmtInfoInvoiceDetails;
	}

	public String getRmtInfoPaymentDetails() {
		return this.rmtInfoPaymentDetails;
	}

	public void setRmtInfoPaymentDetails(String rmtInfoPaymentDetails) {
		this.rmtInfoPaymentDetails = rmtInfoPaymentDetails;
	}

	public String getSenderAccountNo() {
		return this.senderAccountNo;
	}

	public void setSenderAccountNo(String senderAccountNo) {
		this.senderAccountNo = senderAccountNo;
	}

	public String getSenderBankCountryCode() {
		return this.senderBankCountryCode;
	}

	public void setSenderBankCountryCode(String senderBankCountryCode) {
		this.senderBankCountryCode = senderBankCountryCode;
	}

	public String getSenderMandateId() {
		return this.senderMandateId;
	}

	public void setSenderMandateId(String senderMandateId) {
		this.senderMandateId = senderMandateId;
	}

	public String getSenderName() {
		return this.senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getSenderSwiftBic() {
		return this.senderSwiftBic;
	}

	public void setSenderSwiftBic(String senderSwiftBic) {
		this.senderSwiftBic = senderSwiftBic;
	}

	public double getTxnAmount() {
		return this.txnAmount;
	}

	public void setTxnAmount(double txnAmount) {
		this.txnAmount = txnAmount;
	}

	public String getTxnCcy() {
		return this.txnCcy;
	}

	public void setTxnCcy(String txnCcy) {
		this.txnCcy = txnCcy;
	}

	public String getTxnDate() {
		return this.txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	public String getTxnRefId() {
		return this.txnRefId;
	}

	public void setTxnRefId(String txnRefId) {
		this.txnRefId = txnRefId;
	}

	public String getTxnRejectCode() {
		return this.txnRejectCode;
	}

	public void setTxnRejectCode(String txnRejectCode) {
		this.txnRejectCode = txnRejectCode;
	}

	public double getTxnSettlementAmt() {
		return this.txnSettlementAmt;
	}

	public void setTxnSettlementAmt(double txnSettlementAmt) {
		this.txnSettlementAmt = txnSettlementAmt;
	}

	public Date getTxnSettlementDate() {
		return this.txnSettlementDate;
	}

	public void setTxnSettlementDate(Date txnSettlementDate) {
		this.txnSettlementDate = txnSettlementDate;
	}

	public String getTxnStatus() {
		return this.txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public String getTxnStatusDescription() {
		return this.txnStatusDescription;
	}

	public void setTxnStatusDescription(String txnStatusDescription) {
		this.txnStatusDescription = txnStatusDescription;
	}

	public String getTxnType() {
		return this.txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public H5Txn getH5Txn() {
		return this.h5Txn;
	}

	public void setH5Txn(H5Txn h5Txn) {
		this.h5Txn = h5Txn;
	}

}